
const acc = document.getElementsByClassName("accordion-alm");
var i;
var turnstileToken;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
            panel.style.maxHeight = null;
        } else {
            panel.style.maxHeight = panel.scrollHeight + "px";
        }
    });
}


document.addEventListener('DOMContentLoaded', function () {
    // Close the popup when clicking outside of it
    window.addEventListener('click', function (event) {
        var popup = document.getElementById('hajj-popup');
        if (event.target === popup) {
            closeHajjPopup();
        }
    });
});


function openHajjPopup() {
    var popup = document.getElementById('hajj-popup');
    popup.style.display = 'block';
    document.getElementById('footer-outer').style.display = 'none';
    document.getElementById('header-outer').style.display = 'none';
    var elements = document.getElementsByClassName("span_12");

    for (var i = 0; i < elements.length; i++) {
        elements[i].style.zIndex = "unset";
    }
}

function closeHajjPopup() {
    var popup = document.getElementById('hajj-popup');
    popup.style.display = 'none';
    document.getElementById('footer-outer').style.display = 'block';
    document.getElementById('header-outer').style.display = 'none';
    var elements = document.getElementsByClassName("span_12");

    for (var i = 0; i < elements.length; i++) {
        elements[i].style.zIndex = "10";
    }

}

window.onloadTurnstileCallback = function () {
    turnstile.render('#example', {
        sitekey: phpVals.turnstile,
        callback: function (token) {
            turnstileToken = token;
        },
    });
};


function getDonationTypeValue() {
    const summaryDonationAmount = document.getElementById('summaryDonationAmount');
    const bothCustomAmount = document.getElementById('bothCustomerAmount');
    bothCustomAmount.value = '';
    summaryDonationAmount.value = '';
    const donationTypeValue = document.getElementById('donationTypeOne');
    const donationTypeValueTwo = document.getElementById('donationTypeTwo');
    const typeSelectedValue = document.getElementById('summarySelectedType');
    typeSelectedValue.value = donationTypeValue.value;
    donationTypeValue.classList.add('active');
    donationTypeValueTwo.classList.remove('active');
    document.getElementById("summaryPresetOneTime").style.display = "block";
    document.getElementById("summaryPresetRecurring").style.display = "none";
    resetPresetAndCustomAmount(true);
}


function getDonationTypeValueTwo() {
    const summaryDonationAmount = document.getElementById('summaryDonationAmount');
    const bothCustomAmount = document.getElementById('bothCustomerAmount');
    bothCustomAmount.value = '';
    summaryDonationAmount.value = '';
    const donationTypeValue = document.getElementById('donationTypeTwo');
    const donationTypeValueOne = document.getElementById('donationTypeOne');
    const typeSelectedValue = document.getElementById('summarySelectedType');
    typeSelectedValue.value = donationTypeValue.value;

    donationTypeValue.classList.add('active');
    donationTypeValueOne.classList.remove('active');
    document.getElementById("summaryPresetOneTime").style.display = "none";
    document.getElementById("summaryPresetRecurring").style.display = "block";
    resetPresetAndCustomAmount(true);
}


let transactionRecurringAmount = 0;
let isOntimeTransaction = false;
let oneTimeDonateDate;
async function donate(baseUrl, fundraisingId, currencyId, redirectToUrl = null) {
    const form2 = document.getElementById('formElem2');
    const form3 = document.getElementById('formElem3');
    const amount = document.getElementById('my-input-field');
    const submitButton = document.getElementById('submitButton');

    oneTimeDonateDate = {
        "primary": "alm",
        "email": form2.elements.email.value,
        "currency_id": currencyId,
        "number": form2.elements.cardno.value,
        "exp_month": form2.elements.mm.value,
        "exp_year": form2.elements.yy.value,
        "cvc": form2.elements.cvc.value,
        "name_full": form2.elements.name.value,
    }

    const body = {
        "primary": "alm",
        "email": form2.elements.email.value,
        "currency_id": currencyId,
        "card": {
            "number": form2.elements.cardno.value,
            "exp_month": form2.elements.mm.value,
            "exp_year": form2.elements.yy.value,
            "cvc": form2.elements.cvc.value
        },
        "name_full": form2.elements.name.value,
        "alm": [
            {
                "amount_due": isTransactionFee ? parseFloat(amount.value) + parseFloat(transactionAmount) : amount.value,
                "allow_pwyc": false,
                "currency_id": currencyId,
                "is_anonymous": form3.elements.anonymous.checked,
                "items": [
                    {
                        "user_email": form2.elements.email.value,
                        "item": {
                            "type": "donation",
                            "source_id": fundraisingId
                        },
                        "amount_transaction": isTransactionFee ? transactionAmount : 0,
                        "amount": isTransactionFee ? parseFloat(amount.value) + parseFloat(transactionAmount) : amount.value
                    }
                ]
            }
        ]
    }

    let intentBody = {
        "email": form2.elements.email.value,
        "applicable_type": "donation",
        "applicable_id": fundraisingId,
        "token": turnstileToken,
    }

    submitButton.disabled = true;
    submitButton.classList.add("loader")
    frameload(false);

    await checkoutIntent(baseUrl, intentBody).then(async res => {
        await checkout(baseUrl, body).then(res => {
            submitButton.classList.remove("loader");
            document.getElementById("donation-step-two").style.display = "none";
            var x = document.getElementById("snackbar-success");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 4000);

            if (!redirectToUrl) {
                document.getElementById("donation-step-three").style.display = "block";
            }
            else {
                window.location.assign(redirectToUrl);
            }

            let recurringCheckbox = document.getElementById('recurring_onTime_transaction');
            turnstile.reset('#example');
            transactionRecurringAmount = (15 / 100) * 3.5;
            transactionRecurringAmount = parseFloat(transactionRecurringAmount.toFixed(2));
            document.getElementById("recurring_transaction_onTime_amount").innerHTML = 15;
            document.getElementById("oneTimeCurrency").innerHTML = oneTimeRecurringCurrency;
            document.getElementById("oneTimeCurrency").style.color = 'white';
            document.getElementById("oneTimeCurrency").style.fontSize = '12px';

            document.getElementById("amount_transaction_calculated").innerHTML = transactionRecurringAmount;
            document.getElementById("amount_transaction_calculated").style.color = 'white';
            document.getElementById("amount_transaction_calculated").style.fontSize = '16px';
            document.getElementById("amount_transaction_calculated").style.marginRight = '5px';

            document.getElementById("recurring_transaction_onTime_amount").style.color = 'white';
            document.getElementById("recurring_transaction_onTime_amount").style.fontSize = '24px';
            document.getElementById("recurring_transaction_onTime_amount").style.marginRight = '5px';
            document.getElementById('closeWindowThankyou').style.display = 'none';
            document.getElementById('formElem2').reset();
            document.getElementById('formElem3').reset();

            recurringCheckbox.addEventListener('click', (event) => {
                if (event.target.checked) {
                    isOntimeTransaction = true;
                    document.getElementById("recurring_transaction_onTime_amount").innerHTML = parseFloat(15) + parseFloat(transactionRecurringAmount);
                } else {
                    isOntimeTransaction = false;
                    document.getElementById("recurring_transaction_onTime_amount").innerHTML = 15;
                }
            });

        }, checkoutError => {
            checkoutError.then(error => {
                if (error.errors["card.number"]) {
                    document.getElementById("snackbar-err").innerHTML = error.errors["card.number"];
                }
                else if (error.errors["card.exp_month"]) {
                    document.getElementById("snackbar-err").innerHTML = error.errors["card.exp_month"];
                }
                else if (error.errors["card.exp_year"]) {
                    document.getElementById("snackbar-err").innerHTML = error.errors["card.exp_year"];
                }
                else if (error.errors["card.cvc"]) {
                    document.getElementById("snackbar-err").innerHTML = error.errors["card.cvc"];
                }
                else if (error.errors["data"]) {
                    document.getElementById("snackbar-err").innerHTML = error.errors["data"];
                }
                else {
                    document.getElementById("snackbar-err").innerHTML = error.errors.error;
                }
            })

            submitButton.classList.remove("loader");
            submitButton.disabled = false;
            var x = document.getElementById("snackbar-err");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
        })

    }, err => {
        err.then(error => {
            console.log(error.errors["email"]);
            if (error.errors["email"]) {
                document.getElementById("snackbar-err").innerHTML = error.errors["email"];
            }
        })

        submitButton.classList.remove("loader");
        submitButton.disabled = false;
        var x = document.getElementById("snackbar-err");
        x.className = "show";
        setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
    })
}


async function checkoutIntent(baseUrl, payload) {
    return new Promise((resolve, reject) => {
        apiCall('POST', baseUrl + 'checkout-intents', payload, 'cors').then(async (res) => {
            if (!res.ok) {
                reject(res.json());
            } else {
                resolve(res);
            }
        })
    })
}


async function checkout(baseUrl, payload) {
    return new Promise((resolve, reject) => {
        apiCall('POST', baseUrl + 'fe/checkout', payload, 'cors').then(async (res) => {
            if (!res.ok) {
                reject(res.json());
            } else {
                resolve(res);
            }
        })
    })
}


async function apiCall(method, url, payload, cors = 'no-cors') {
    return await fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'Application/json',
            'Src-Url': window.location.href,
        },
        mode: cors,
        body: JSON.stringify(payload)
    });
}


function donateButtonHandler(event) {
    var donateButton = document.getElementById('donateButton');


    if (event.target.value > 0) {
        donateButton.disabled = false;
    } else {
        donateButton.disabled = true;
    }
}

function validateEmail(email) {
    var pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return pattern.test(email);
}

function validateSubmitButton() {
    var cardNo = document.getElementById('card-number');
    var name = document.getElementById('name');
    var email = document.getElementById('email');
    var expMonth = document.getElementById('month');
    var expYear = document.getElementById('year');
    var cvc = document.getElementById('cvc');
    var submitButton = document.getElementById('submitButton');

    if (email.value && cardNo.value && name.value && expMonth.value && expYear.value && cvc.value) {
        if (validateEmail(email.value)) {
            submitButton.disabled = false;
        } else {
            submitButton.disabled = true;
        }
    }
    else {
        submitButton.disabled = true;
    }
}

async function openPopup(amount, currency, stepTwo = false) {
    var myInputField = document.getElementById('my-input-field');

    var submitButton = document.getElementById('submitButton');
    submitButton.disabled = true;


    myInputField.addEventListener('change', donateButtonHandler, false);
    myInputField.addEventListener('keyup', donateButtonHandler, false);

    jQuery('[popup-name="' + 'popup-1' + '"]').fadeIn(300);

    if (stepTwo) {
        document.getElementById("donation-step-two").style.display = "block";
        document.getElementById("donation-step-one").style.display = "none";
        toggleStep(amount, currency)
    } else {
        document.getElementById("donation-step-one").style.display = "block";
    }

    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById("header-outer").style.display = "none";

    var myInputField = document.getElementById('my-input-field');
    myInputField.value = amount ? amount : null;

    jQuery('.video__placeholder').ready(function () {
        if (!jQuery('#video-player').length) {
            var video = '<iframe id="video-player" src="' + jQuery('.video__placeholder').attr('data-video') + '" frameborder="0" allow="autoplay; fullscreen;" allowfullscreen onload="frameload(true)" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>';

            jQuery(video).insertAfter(jQuery('.video__placeholder'));
        } else {
            jQuery('.video__button').removeClass('is-playing');
            jQuery('#video-player').remove();
        }
    });
}

async function openPopupOneTime(amount, currency, stepTwo = false) {
    var myInputField = document.getElementById('my-input-field');
    var submitButton = document.getElementById('submitButton');
    submitButton.disabled = true;
    myInputField.addEventListener('change', donateButtonHandler, false);
    myInputField.addEventListener('keyup', donateButtonHandler, false);

    jQuery('[popup-name="' + 'popup-1' + '"]').fadeIn(300);

    if (stepTwo) {
        var tStep = document.getElementById('toggleStep');
        document.getElementById("donation-step-two").style.display = "block";
        document.getElementById("donation-step-one").style.display = "none";

        if (document.getElementById("bothCustomerAmount").value == '') {
            if (tStep.value == 'btn1') {
                toggleStepOne(amount, currency);

            } else if (tStep.value == 'btn2') {
                toggleStepTwo(amount, currency);

            } else if (tStep.value == 'btn3') {
                toggleStepThree(amount, currency);

            }
            //  else {
            //     toggleStep();
            // }
        } else {
            toggleStep(amount, currency);
        }
        // toggleStepTwo(amount, currency)
        // toggleStepThree(amount, currency)
    } else {
        toggleStep(amount, currency);
    }

    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById("header-outer").style.display = "none";

    var myInputField = document.getElementById('my-input-field');
    myInputField.value = amount ? amount : null;

    jQuery('.video__placeholder').ready(function () {
        if (!jQuery('#video-player').length) {
            var video = '<iframe id="video-player" src="' + jQuery('.video__placeholder').attr('data-video') + '" frameborder="0" allow="autoplay; fullscreen;" allowfullscreen onload="frameload(true)" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>';

            jQuery(video).insertAfter(jQuery('.video__placeholder'));
        } else {
            jQuery('.video__button').removeClass('is-playing');
            jQuery('#video-player').remove();
        }
    });
}


function frameload(remove = false) {
    const videoDiv = document.getElementById('videoPlayer');

    if (remove) {
        videoDiv.classList.remove('video-loader');
    } else {
        videoDiv.classList.add('video-loader');
    }
}


function reloadPage() {
    const closeButton = document.getElementById('closeButton');

    closeButton.disabled = true;
    closeButton.classList.add("loader")

    setTimeout(() => {
        window.location.reload();
    }, 1500);
}


function closePopup1() {
    console.log(';called');
    jQuery('[popup-name="' + 'popup-1' + '"]').fadeOut(300);
    document.getElementById("top").style.display = "block";
    document.getElementById("footer-outer").style.display = "block";
    document.getElementById("header-outer").style.display = "block";
    document.getElementById("donation-step-two").style.display = "none";
    document.getElementById("donation-expanded").style.display = "none";
    document.getElementById("donation-expanded").style.display = "none";
    document.getElementById("donation-step-three").style.display = "none";
    document.getElementById("btn1").style.background = "#F4F0EF";
    document.getElementById("btn2").style.background = "#F4F0EF";
    document.getElementById("btn3").style.background = "#F4F0EF";
    document.getElementById("btn4").style.background = "#F4F0EF";
    document.getElementById("btn5").style.background = "#F4F0EF";
    document.getElementById("btn6").style.background = "#F4F0EF";
    document.getElementById("btn1").style.color = "#000";
    document.getElementById("btn2").style.color = "#000";
    document.getElementById("btn3").style.color = "#000";
    document.getElementById("btn4").style.color = "#000";
    document.getElementById("btn5").style.color = "#000";
    document.getElementById("btn6").style.color = "#000";
    document.getElementById('bothCustomerAmount').value = '';
    const summaryDonationAmount = document.getElementById('summaryDonationAmount');
    summaryDonationAmount.value = '';
    var myInputField = document.getElementById('my-input-field');
    myInputField.value = null;
    document.getElementById('formElem2').reset();
    document.getElementById('formElem3').reset();
    donateButton.disabled = true;
}


function showOneOffPopup() {
    closePopup2();
    openPopup();
}

function showRecurringPopup() {
    closePopup1();
    openPopupRecurring();
}

function toggleLevel() {
    // debugger
    var x = document.getElementById("donation-expanded");
    if (x.style.display == "none") {
        document.getElementById("donation-expanded").style.display = "block";
        document.getElementById("donation-step-one").style.display = "none";
    } else {
        x.style.display = "none";
        document.getElementById("donation-step-one").style.display = "block";
    }
}

let transactionAmount = 0;
let isTransactionFee = false;
let oneTimeRecurringCurrency = '';
function toggleStep(amount = 0, currency = 'USD', symbol = '$') {
    var myInputField = document.getElementById('my-input-field');
    const transactionCheckbox = document.getElementById('transaction');
    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";

    if (myInputField.value && !amount) {
        amount = myInputField.value;
    } else {
        myInputField.value = amount;
    }
    // document.getElementById('bothCustomerAmount').value = "";

    const selectedAmount = document.getElementById('summaryDonationAmount');
    if (selectedAmount) {
        selectedAmount.value = amount;
    }

    document.getElementById("donation-step-one").style.display = "none";
    document.getElementById("donation-expanded").style.display = "none";
    document.getElementById("donation-step-two").style.display = "block";
    document.getElementById("headingAmount").innerHTML = amount;
    document.getElementById("headingAmountCurrency").textContent = currency;

    transactionAmount = (amount / 100) * 3.5;
    transactionAmount = parseFloat(transactionAmount.toFixed(2));
    document.getElementById("transaction_amount").innerHTML = parseFloat(transactionAmount.toFixed(2)) + ' ' + currency;
    oneTimeRecurringCurrency = currency;

    document.getElementById("transaction_amount").style.color = 'black';

    transactionCheckbox.addEventListener('click', (event) => {
        if (event.target.checked) {
            isTransactionFee = true;
            document.getElementById("headingAmount").innerHTML = parseFloat(amount) + parseFloat(transactionAmount);
        } else {
            isTransactionFee = false;
            document.getElementById("headingAmount").innerHTML = amount;
        }
    });
    turnstile.reset('#example');
}

function toggleStepOne(amount = 0, currency = 'USD', symbol = '$') {
    var myInputField = document.getElementById('my-input-field');
    var btn1 = document.getElementById('btn1');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn1.value;
    document.getElementById('err-message').style.display = "none";
    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";

    if (myInputField.value && !amount) {
        amount = myInputField.value;
    } else {
        myInputField.value = amount;
    }
    document.getElementById('bothCustomerAmount').value = "";

    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;


    document.getElementById("btn1").style.background = "#576aff";
    document.getElementById("btn2").style.background = "#F4F0EF";
    document.getElementById("btn3").style.background = "#F4F0EF";
    document.getElementById("btn1").style.color = "white";
    document.getElementById("btn2").style.color = "#000";
    document.getElementById("btn3").style.color = "#000";
    document.getElementById("donation-step-two").style.display = "block";
    document.getElementById("headingAmount").innerHTML = amount;
    document.getElementById("headingAmountCurrency").textContent = currency;
    turnstile.reset('#example');
}

function toggleStepTwo(amount = 0, currency = 'USD', symbol = '$') {
    var myInputField = document.getElementById('my-input-field');
    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById('err-message').style.display = "none";


    var btn2 = document.getElementById('btn2');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn2.value;

    if (myInputField.value && !amount) {
        amount = myInputField.value;
    } else {
        myInputField.value = amount;
    }
    document.getElementById('bothCustomerAmount').value = "";

    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;

    document.getElementById("btn2").style.background = "#576aff";
    document.getElementById("btn1").style.background = "#F4F0EF";
    document.getElementById("btn3").style.background = "#F4F0EF";
    document.getElementById("btn2").style.color = "white";
    document.getElementById("btn1").style.color = "#000";
    document.getElementById("btn3").style.color = "#000";
    document.getElementById("donation-step-two").style.display = "block";
    document.getElementById("headingAmount").innerHTML = amount;
    document.getElementById("headingAmountCurrency").textContent = currency;
    turnstile.reset('#example');
}

function toggleStepThree(amount = 0, currency = 'USD', symbol = '$') {
    var myInputField = document.getElementById('my-input-field');
    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById('err-message').style.display = "none";

    var btn3 = document.getElementById('btn3');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn3.value;

    if (myInputField.value && !amount) {
        amount = myInputField.value;
    } else {
        myInputField.value = amount;
    }
    document.getElementById('bothCustomerAmount').value = "";

    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;

    document.getElementById("btn3").style.background = "#576aff";
    document.getElementById("btn1").style.background = "#F4F0EF";
    document.getElementById("btn2").style.background = "#F4F0EF";
    document.getElementById("btn3").style.color = "white";
    document.getElementById("btn1").style.color = "#000";
    document.getElementById("btn2").style.color = "#000";
    document.getElementById("donation-step-two").style.display = "block";
    document.getElementById("headingAmount").innerHTML = amount;
    document.getElementById("headingAmountCurrency").textContent = currency;
    turnstile.reset('#example');
}


function progress(amountReceived, amountRequired, isTypeDonor, donorsCount, targetDonors) {
    let percentage;
    // type == donors
    if (isTypeDonor) {
        percentage = ((donorsCount / targetDonors) * 100) > 100 ? 100 :
            (donorsCount / targetDonors) * 100;

        // type == amount
    } else {
        percentage = ((amountReceived / amountRequired) * 100) > 100 ? 100 :
            (amountReceived / amountRequired) * 100;
    }

    var elem = document.getElementById("progressBar");
    elem.style.width = percentage + "%";

    if (percentage >= 100) {
        elem.classList.add('progressBarFull')
    } else if (percentage > 90) {
        elem.classList.add('progressBarGreen');
    } else {
        elem.classList.add('progressBar')
    }

    elem.innerHTML = '&nbsp;'
}


//On time recurring function

/**
 * donateRecurrigFromOneTimePopup
 */
async function donateRecurringFromOnTime(baseUrl, fundraisingId, currencyId) {
    const amount = 15;
    const submitButton = document.getElementById('submitRecurringButton');
    let now = new Date();

    // Adding 30 days
    let futureDate = new Date(now.getTime() + (30 * 24 * 60 * 60 * 1000));
    let futureYear = futureDate.getFullYear();
    let futureMonth = (futureDate.getMonth() + 1).toString().padStart(2, '0');

    let maxDaysInMonth = new Date(futureYear, futureMonth, 0).getDate();
    if (futureDate.getDate() > maxDaysInMonth) {
        futureDate.setDate(maxDaysInMonth);
    }

    let futureDay = futureDate.getDate().toString().padStart(2, '0');
    let futureFormattedDate = `${futureYear}-${futureMonth}-${futureDay}`;

    const body = {
        "currency_id": currencyId,
        "timezone_id": 1,
        "email": oneTimeDonateDate.email,
        "name_full": oneTimeDonateDate.name_full,
        "card_digits": oneTimeDonateDate.number,
        "card_exp_month": oneTimeDonateDate.exp_month,
        "card_exp_year": oneTimeDonateDate.exp_year,
        "card_cvc": oneTimeDonateDate.cvc,
        "amount": isOntimeTransaction ? parseFloat(amount) + parseFloat(transactionRecurringAmount) : amount,
        "status": 'active',
        "date_start": futureFormattedDate,
        "amount_transaction": isOntimeTransaction ? parseFloat(transactionRecurringAmount) : 0,
        "date_end": '',
        "occurrence": 1000,
        "recurring_cycle": 'monthly'
    }

    let intentBody = {
        "email": oneTimeDonateDate.email,
        "applicable_type": "donation",
        "applicable_id": fundraisingId,
        "token": turnstileToken,
    }
    submitButton.disabled = true;
    submitButton.classList.add("loader")

    await checkoutIntentRecurring(baseUrl, intentBody).then(async res => {
        await checkoutRecurring(baseUrl, body, fundraisingId).then(res => {
            submitButton.classList.remove("loader");
            document.getElementById('formElemRecurring').reset();
            document.getElementById("oneTimeThankyou").style.display = 'none';
            document.getElementById("oneTimeThankyouSuccess").style.display = 'block';

            document.getElementById("success-message").innerHTML = 'Your monthly recurring donation has been scheduled. First deduction will be on' + ' ' + futureFormattedDate;
            document.getElementById("success-message").style.color = 'green';
            document.getElementById("success-message").style.marginTop = '5px';
            document.getElementById("success-message").style.fontWeight = '16px';
            document.getElementById('closeButton').style.display = 'none';
            document.getElementById('closeWindowThankyou').style.display = 'block';
        }, checkoutError => {
            checkoutError.then(error => {

                if (error.errors["card.number"]) {

                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.number"];
                }
                else if (error.errors["Card error"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors.error["Card error"];
                }
                else if (error.errors["card.exp_month"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.exp_month"];
                }
                else if (error.errors["card.exp_year"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.exp_year"];
                }
                else if (error.errors["card.cvc"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.cvc"];
                }
                else if (error.errors["data"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["data"];
                }
                else {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors;
                }
            })

            submitButton.classList.remove("loader");
            submitButton.disabled = false;
        })

    }, err => {
        err.then(error => {
            console.log(error.errors["email"]);
            if (error.errors["email"]) {
            }
        })

        submitButton.classList.remove("loader");
        submitButton.disabled = false;
    })
}


// Recurring functions start here.

/**
 * donateRecurring
 */
async function donateRecurring(baseUrl, dateStart, dateEnd, currencyId, fundraisingId, recurringCycle, occurrence = null, chargeTimeStart = null, chargeTimeEnd = null, timezoneId = 1, redirectToUrl = null) {
    const form2 = document.getElementById('formElemRecurring');
    const submitButton = document.getElementById('submitButton-recurring');
    const amount = document.getElementById("headingAmountRecurring");

    const body = {
        "currency_id": currencyId,
        "timezone_id": timezoneId,
        "email": form2.elements.email.value,
        "name_full": form2.elements.name.value,
        "card_digits": form2.elements.cardno.value,
        "card_exp_month": form2.elements.mm.value,
        "card_exp_year": form2.elements.yy.value,
        "card_cvc": form2.elements.cvc.value,
        "amount": amount.textContent,
        "status": 'active',
        "date_start": dateStart,
        "amount_transaction": isTransactionFee ? parseFloat(transactionAmount) : 0,
        "date_end": dateEnd,
        "occurrence": occurrence,
        "recurring_cycle": recurringCycle.toLowerCase()
    }

    if (chargeTimeStart) {
        Object.assign(body, { "charge_time_start": chargeTimeStart })
    }

    if (chargeTimeEnd) {
        Object.assign(body, { "charge_time_end": chargeTimeEnd })
    }

    let intentBody = {
        "email": form2.elements.email.value,
        "applicable_type": "recurring_payment",
        "applicable_id": fundraisingId,
        "token": turnstileToken,
    }

    submitButton.disabled = true;
    submitButton.classList.add("loader")
    frameload(false);


    /**
     * checkoutIntentRecurring
     */
    await checkoutIntentRecurring(baseUrl, intentBody).then(async res => {
        await checkoutRecurring(baseUrl, body, fundraisingId).then(res => {
            submitButton.classList.remove("loader");
            document.getElementById("recurring-step-two").style.display = "none";
            var x = document.getElementById("recurring-snackbar-success");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);

            if (!redirectToUrl) {
                document.getElementById("recurring-step-three").style.display = "block";
            }
            else {
                window.location.assign(redirectToUrl);
            }
        }, checkoutError => {
            checkoutError.then(error => {

                if (error.errors["card.number"]) {

                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.number"];
                }
                else if (error.errors["Card error"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors.error["Card error"];
                }
                else if (error.errors["card.exp_month"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.exp_month"];
                }
                else if (error.errors["card.exp_year"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.exp_year"];
                }
                else if (error.errors["card.cvc"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["card.cvc"];
                }
                else if (error.errors["data"]) {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors["data"];
                }
                else {
                    document.getElementById("recurring-snackbar-err").innerHTML = error.errors;
                }
            })

            submitButton.classList.remove("loader");
            submitButton.disabled = false;
            var x = document.getElementById("recurring-snackbar-err");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
        })

    }, err => {
        err.then(error => {
            console.log(error.errors["email"]);
            if (error.errors["email"]) {
                document.getElementById("recurring-snackbar-err").innerHTML = error.errors["email"];
            }
        })

        submitButton.classList.remove("loader");
        submitButton.disabled = false;
        var x = document.getElementById("recurring-snackbar-err");
        x.className = "show";
        setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
    })
}


/**
 * checkoutIntentRecurring
 */
async function checkoutIntentRecurring(baseUrl, payload) {
    return new Promise((resolve, reject) => {
        apiCall('POST', baseUrl + 'checkout-intents', payload, 'cors').then(async (res) => {
            if (!res.ok) {
                reject(res.json());
            } else {
                resolve(res);
            }
        })
    })
}

/**
 * checkoutRecurring
 */
async function checkoutRecurring(baseUrl, payload, fundraisingId) {
    return new Promise((resolve, reject) => {
        apiCall('POST', baseUrl + 'fundraisings/' + fundraisingId + '/recurring', payload, 'cors').then(async (res) => {
            if (!res.ok) {
                reject(res.json());
            } else {
                resolve(res);
            }
        })
    })
}


/**
 * donateButtonHandlerRecurring
 */
function donateButtonHandlerRecurring(event) {
    var donateButton = document.getElementById('donateButton-recurring');


    if (event.target.value > 0) {
        donateButton.disabled = false;
    } else {
        donateButton.disabled = true;
    }
}


/**
 * validateSubmitButtonRecurring
 */
function validateSubmitButtonRecurring() {
    var cardNo = document.getElementById('card-number-recurring');
    var name = document.getElementById('name-recurring');
    var email = document.getElementById('email-recurring');
    var expMonth = document.getElementById('month-recurring');
    var expYear = document.getElementById('year-recurring');
    var cvc = document.getElementById('cvc-recurring');
    var submitButton = document.getElementById('submitButton-recurring');

    if (email.value && cardNo.value && name.value && expMonth.value && expYear.value && cvc.value) {
        if (validateEmail(email.value)) {
            submitButton.disabled = false;
        } else {
            submitButton.disabled = true;
        }
    }
    else {
        submitButton.disabled = true;
    }
}

/**
 * openPopupRecurring
 */
async function openPopupRecurring(amount, currency, stepTwo = false) {
    var myInputField = document.getElementById('my-input-field-recurring');

    var submitButton = document.getElementById('submitButton-recurring');
    submitButton.disabled = true;

    myInputField.addEventListener('change', donateButtonHandlerRecurring, false);
    myInputField.addEventListener('keyup', donateButtonHandlerRecurring, false);

    jQuery('[popup-name="' + 'popup-2' + '"]').fadeIn(300);

    if (stepTwo) {
        toggleStep(amount, currency)
    } else {
        document.getElementById("recurring-step-one").style.display = "block";
    }

    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById("header-outer").style.display = "none";

    var myInputField = document.getElementById('my-input-field-recurring');
    myInputField.value = amount ? amount : null;

    jQuery('.video__placeholder').ready(function () {
        if (!jQuery('#video-player').length) {
            var video = '<iframe id="video-player" src="' + jQuery('.video__placeholder').attr('data-video') + '" frameborder="0" allow="autoplay; fullscreen;" allowfullscreen onload="frameload(true)" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>';

            jQuery(video).insertAfter(jQuery('.video__placeholder'));
        } else {
            jQuery('.video__button').removeClass('is-playing');
            jQuery('#video-player').remove();
        }
    });
}



/**
 * openPopupRecurring2
 */
async function openPopupRecurring2(amount, currency, stepTwo = false) {
    console.log(amount, "amount")
    var myInputField = document.getElementById('my-input-field-recurring');
    var submitButton = document.getElementById('submitButton-recurring');
    submitButton.disabled = true;

    myInputField.addEventListener('change', donateButtonHandlerRecurring, false);
    myInputField.addEventListener('keyup', donateButtonHandlerRecurring, false);

    jQuery('[popup-name="' + 'popup-2' + '"]').fadeIn(300);

    if (stepTwo) {
        document.getElementById("headingAmountRecurring").innerHTML = amount;
        document.getElementById("recurring-step-one").style.display = "none";
        document.getElementById("recurring-step-two").style.display = "block";
        var tStep = document.getElementById('toggleStep');

        if (document.getElementById("bothCustomerAmount").value == '') {
            if (tStep.value == 'btn4') {
                preDefinedAmountSelectRecurring1(amount, currency);

            } else if (tStep.value == 'btn5') {
                preDefinedAmountSelectRecurring2(amount, currency);

            } else if (tStep.value == 'btn6') {
                preDefinedAmountSelectRecurring3(amount, currency);
            }
        }
    } else {
        document.getElementById("recurring-step-one").style.display = "block";
    }

    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    document.getElementById("header-outer").style.display = "none";

    var myInputField = document.getElementById('my-input-field-recurring');
    myInputField.value = amount ? amount : null;

    jQuery('.video__placeholder').ready(function () {
        if (!jQuery('#video-player').length) {
            var video = '<iframe id="video-player" src="' + jQuery('.video__placeholder').attr('data-video') + '" frameborder="0" allow="autoplay; fullscreen;" allowfullscreen onload="frameload(true)" style="position:absolute;top:0;left:0;width:100%;height:100%;"></iframe>';

            jQuery(video).insertAfter(jQuery('.video__placeholder'));
        } else {
            jQuery('.video__button').removeClass('is-playing');
            jQuery('#video-player').remove();
        }
    });
}



/**
 * Recurring
 */
function closePopup2() {
    jQuery('[popup-name="' + 'popup-2' + '"]').fadeOut(300);
    document.getElementById("top").style.display = "block";
    document.getElementById("footer-outer").style.display = "block";
    document.getElementById("header-outer").style.display = "block";
    document.getElementById("recurring-step-two").style.display = "none";
    document.getElementById("donation-expanded").style.display = "none";
    const summaryDonationAmount = document.getElementById('summaryDonationAmount');
    document.getElementById("donation-step-three").style.display = "none";
    document.getElementById("btn1").style.background = "#F4F0EF";
    document.getElementById("btn2").style.background = "#F4F0EF";
    document.getElementById("btn3").style.background = "#F4F0EF";
    document.getElementById("btn4").style.background = "#F4F0EF";
    document.getElementById("btn5").style.background = "#F4F0EF";
    document.getElementById("btn6").style.background = "#F4F0EF";
    document.getElementById("btn1").style.color = "#000";
    document.getElementById("btn2").style.color = "#000";
    document.getElementById("btn3").style.color = "#000";
    document.getElementById("btn4").style.color = "#000";
    document.getElementById("btn5").style.color = "#000";
    document.getElementById("btn6").style.color = "#000";
    document.getElementById('bothCustomerAmount').value = '';
    summaryDonationAmount.value = '';
    var myInputField = document.getElementById('my-input-field-recurring');
    myInputField.value = null;
    document.getElementById('formElemRecurring').reset();
    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = true;

    document.getElementById("btnAmount1").style.background = "#EFEFEF";
    document.getElementById("btnAmount2").style.background = "#EFEFEF";
    document.getElementById("btnAmount3").style.background = "#EFEFEF";

    document.getElementById("btnAmount1").style.color = "#5F5F5F";
    document.getElementById("btnAmount2").style.color = "#5F5F5F";
    document.getElementById("btnAmount3").style.color = "#5F5F5F";

}


/**
 * preDefinedAmountSelect1 (Recurring)
 */
var preDefinedAmount = 0;
function preDefinedAmountSelect1(amount, currency, symbol = '$') {
    console.log('called', amount);
    preDefinedAmount = amount;


    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;

    //reset field value
    document.getElementById('my-input-field-recurring').value = "";

    document.getElementById("btnAmount1").style.background = "#576aff";
    document.getElementById("btnAmount2").style.background = "#EFEFEF";
    document.getElementById("btnAmount3").style.background = "#EFEFEF";
    document.getElementById("btnAmount1").style.color = "white";
    document.getElementById("btnAmount2").style.color = "#5F5F5F";
    document.getElementById("btnAmount3").style.color = "#5F5F5F";
    document.getElementById("headingAmountRecurring").innerHTML = amount;


    // document.getElementById("headingAmountRecurring").innerHTML = amount;
}


function preDefinedAmountSelect2(amount, currency, symbol = '$') {
    preDefinedAmount = amount;
    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;

    //reset field value
    document.getElementById('my-input-field-recurring').value = "";

    document.getElementById("btnAmount2").style.background = "#576aff";
    document.getElementById("btnAmount1").style.background = "#EFEFEF";
    document.getElementById("btnAmount3").style.background = "#EFEFEF";
    document.getElementById("btnAmount2").style.color = "white";
    document.getElementById("btnAmount1").style.color = "#5F5F5F";
    document.getElementById("btnAmount3").style.color = "#5F5F5F";


    document.getElementById("headingAmountRecurring").innerHTML = amount;
}


function preDefinedAmountSelect3(amount, currency, symbol = '$') {
    preDefinedAmount = amount;
    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;

    //reset field value
    document.getElementById('my-input-field-recurring').value = "";

    document.getElementById("btnAmount3").style.background = "#576aff";
    document.getElementById("btnAmount1").style.background = "#EFEFEF";
    document.getElementById("btnAmount2").style.background = "#EFEFEF";
    document.getElementById("btnAmount3").style.color = "white";
    document.getElementById("btnAmount1").style.color = "#5F5F5F";
    document.getElementById("btnAmount2").style.color = "#5F5F5F";

    document.getElementById("headingAmountRecurring").innerHTML = amount;
}

/**
 * preDefinedAmountSelectRecurring1 (Recurring)
 */

function preDefinedAmountSelectRecurring1(amount, currency, symbol = '$') {
    document.getElementById('err-message').style.display = "none";

    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;
    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;

    var btn4 = document.getElementById('btn4');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn4.value;
    //reset field value
    document.getElementById('my-input-field-recurring').value = "";
    document.getElementById('bothCustomerAmount').value = "";

    document.getElementById("btn4").style.background = "#576aff";
    document.getElementById("btn5").style.background = "#F4F0EF";
    document.getElementById("btn6").style.background = "#F4F0EF";
    document.getElementById("btn4").style.color = "white";
    document.getElementById("btn5").style.color = "#000";
    document.getElementById("btn6").style.color = "#000";
    document.getElementById("headingAmountRecurring").innerHTML = amount;
}

function preDefinedAmountSelectRecurring2(amount, currency, symbol = '$') {
    document.getElementById('err-message').style.display = "none";

    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;
    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;

    var btn5 = document.getElementById('btn5');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn5.value;

    document.getElementById('bothCustomerAmount').value = "";
    //reset field value
    document.getElementById('my-input-field-recurring').value = "";

    document.getElementById("btn5").style.background = "#576aff";
    document.getElementById("btn4").style.background = "#F4F0EF";
    document.getElementById("btn6").style.background = "#F4F0EF";
    document.getElementById("btn5").style.color = "white";
    document.getElementById("btn4").style.color = "#000";
    document.getElementById("btn6").style.color = "#000";


    document.getElementById("headingAmountRecurring").innerHTML = amount;
}


function preDefinedAmountSelectRecurring3(amount, currency, symbol = '$') {
    document.getElementById('err-message').style.display = "none";

    var donateButton = document.getElementById('donateButton-recurring');
    donateButton.disabled = false;
    const selectedAmount = document.getElementById('summaryDonationAmount');
    selectedAmount.value = amount;

    var btn6 = document.getElementById('btn6');
    var toggleStep = document.getElementById('toggleStep');
    toggleStep.value = btn6.value;

    document.getElementById('bothCustomerAmount').value = "";
    //reset field value
    document.getElementById('my-input-field-recurring').value = "";

    document.getElementById("btn6").style.background = "#576aff";
    document.getElementById("btn4").style.background = "#F4F0EF";
    document.getElementById("btn5").style.background = "#F4F0EF";
    document.getElementById("btn6").style.color = "white";
    document.getElementById("btn4").style.color = "#000";
    document.getElementById("btn5").style.color = "#000";

    document.getElementById("headingAmountRecurring").innerHTML = amount;
}

function resetPresetAndCustomAmount(includeCustomAmount = false) {
    const typeSelectedValue = document.getElementById('summarySelectedType');
    const presetRecurringWord = document.getElementsByClassName("preset-recurring-word");
    document.getElementById('err-message').style.display = "none";
    document.getElementById('summaryDonationAmount').value = document.getElementById('bothCustomerAmount').value

    if (typeSelectedValue.value == 'onetime') {
        document.getElementById("btn1").style.background = "#F4F0EF";
        document.getElementById("btn2").style.background = "#F4F0EF";
        document.getElementById("btn3").style.background = "#F4F0EF";
        document.getElementById("btn1").style.color = "#000";
        document.getElementById("btn2").style.color = "#000";
        document.getElementById("btn3").style.color = "#000";

        for (var i = 0; i < presetRecurringWord.length; i++) {
            presetRecurringWord[i].style.display = "none";
        }

    } else {
        document.getElementById("btn4").style.background = "#F4F0EF";
        document.getElementById("btn5").style.background = "#F4F0EF";
        document.getElementById("btn6").style.background = "#F4F0EF";
        document.getElementById("btn4").style.color = "#000";
        document.getElementById("btn5").style.color = "#000";
        document.getElementById("btn6").style.color = "#000";

        for (var i = 0; i < presetRecurringWord.length; i++) {
            presetRecurringWord[i].style.display = "block";
        }
    }

    if (includeCustomAmount) {
        document.getElementById('bothCustomerAmount').value = "";
    }

}

function openPopupForBoth(data) {
    const typeSelectedValue = document.getElementById('summarySelectedType');
    const selectedAmount = document.getElementById('summaryDonationAmount');
    const selectedCustomAmount = document.getElementById('bothCustomerAmount');
    var amount;

    const summaryDonationAmount = document.getElementById('summaryDonationAmount');
    // console.log(summaryDonationAmount.value);
    console.log(typeSelectedValue.value);
    if (summaryDonationAmount.value == '') {
        document.getElementById('err-message').style.display = "block"; return
        // alert('Please Select Amount');
    } else {
        if (selectedCustomAmount.value != '') {
            amount = selectedCustomAmount.value;

        } else {
            amount = selectedAmount.value;
        }

        if (typeSelectedValue.value == 'onetime') {
            console.log(amount);
            console.log(data);
            this.openPopupOneTime(amount, data, true);

        } else if (typeSelectedValue.value == 'recurring') {
            this.openPopupRecurring2(amount, data, true);
        }
    }


}






function toggleStep2(amount = 0, currency = 'USD', symbol = '$') {
    var myInputField = document.getElementById('my-input-field-recurring');
    document.getElementById("top").style.display = "none";
    document.getElementById("footer-outer").style.display = "none";
    const transactionCheckbox = document.getElementById('recurring_transaction');
    if (myInputField.value) {
        // Format the value to show 2 decimal places
        var formattedValue = Number(myInputField.value).toFixed(2);

        if (formattedValue % 1 !== 0) {
            myInputField.value = formattedValue;
        } else {
            myInputField.value = parseInt(formattedValue);
        }

        document.getElementById("headingAmountRecurring").innerHTML = myInputField.value;
        document.getElementById('my-input-field-recurring').innerHTML = myInputField.value;
    }

    document.getElementById("recurring-step-one").style.display = "none";
    document.getElementById("donation-expanded").style.display = "none";
    document.getElementById("recurring-step-two").style.display = "block";
    transactionAmount = (preDefinedAmount / 100) * 3.5;
    transactionAmount = parseFloat(transactionAmount.toFixed(2));

    document.getElementById("recurring_transaction_amount").style.color = 'black';

    document.getElementById("recurring_transaction_amount").innerHTML =
        transactionAmount + ' ' + currency;

    transactionCheckbox.addEventListener('click', (event) => {
        if (event.target.checked) {
            isTransactionFee = true;
            document.getElementById("headingAmountRecurring").innerHTML =
                parseFloat(preDefinedAmount) + parseFloat(transactionAmount);
        } else {
            isTransactionFee = false;
            document.getElementById("headingAmountRecurring").innerHTML = parseFloat(preDefinedAmount);
        }
    });
    turnstile.reset('#example');
}

function resetPredefined(myInputField) {
    if (myInputField.value) {
        document.getElementById("btnAmount1").style.background = "#EFEFEF";
        document.getElementById("btnAmount2").style.background = "#EFEFEF";
        document.getElementById("btnAmount3").style.background = "#EFEFEF";
        document.getElementById("btnAmount1").style.color = "#5F5F5F";
        document.getElementById("btnAmount2").style.color = "#5F5F5F";
        document.getElementById("btnAmount3").style.color = "#5F5F5F";
        preDefinedAmount = myInputField.value;
    }

    if (myInputField.value <= 0) {
        // Reset the input value to 0
        myInputField.value = "";
    }

    // Restrict typing after 2 decimal places
    myInputField.addEventListener('input', restrictDecimalPlaces);
}

function restrictDecimalPlaces(event) {
    var input = event.target.value;
    var regex = /^\d+(\.\d{0,2})?$/;
    if (!regex.test(input)) {
        event.target.value = input.slice(0, -1);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('toggleButtonDetail').addEventListener('click', function () {
        var content = document.getElementById('toggleDivHajjDetail');
        if (content.style.display === 'none' || content.style.display === '') {
            content.style.display = 'block';
        } else {
            content.style.display = 'none';
        }
    });
});
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('toggleButtonDetail2').addEventListener('click', function () {
        var content = document.getElementById('toggleDivHajjDetail2');
        if (content.style.display === 'none' || content.style.display === '') {
            content.style.display = 'block';
        } else {
            content.style.display = 'none';
        }
    });
});
